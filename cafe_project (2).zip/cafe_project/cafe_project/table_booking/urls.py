"""
URL configuration for cafe_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from .views import *

app_name = "table_booking"

urlpatterns = [
    path("home/", home, name="home"),
    path("tables/", tables_list, name="tables_list"),
    path("clients/", clients_list, name="clients_list"),
    path("create-booking/", create_booking, name="create_booking"),
    path("clients/<int:client_id>/", client_detail,name="client_detail"),
    path("bookings/create/", BookingCreateView.as_view(), name="booking_create"),
    path("bookings/", bookings_list, name="bookings_list"),
    path("tables/<int:pk>/", TableDetailView.as_view(), name="table_detail"),

]