from django.apps import AppConfig


class TableBookingConfig(AppConfig):
    name = 'table_booking'
