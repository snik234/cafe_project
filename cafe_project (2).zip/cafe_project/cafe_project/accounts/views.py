from django.shortcuts import render
from django.views.generic import CreateView
from django.views import View
from django.contrib.auth.views import LoginView
from django.contrib.auth import logout
from django.shortcuts import redirect
from .forms import RegisterForm

# Create your views here.


class RegisterView(CreateView):
    form_class = RegisterForm
    template_name = "register.html"
    success_url = "/accounts/login/"
    http_method_names = ["get", "post"]

class CustomLoginView(LoginView):
    template_name = "login.html"

class LogoutView(View):
    def get(self, request, *args, **kwargs):
        logout(request)
        return redirect("/table_booking/home/")

    def post(self, request, *args, **kwargs):
        logout(request)
        return redirect("/table_booking/home/")
